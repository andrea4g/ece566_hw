The work has been done in pair between me (ANTONIO CIPOLLETTA) and ANDREA GUALCO. 
In the current folder it is possible to find:
- the report.
- all the source files for both the implementations.
- utility script used to automatically 
                                      - generate .pbs files.
                                      - submit multiple jobs.
                                      - generate an output summary file with the overall
                                        performance.
- a makefile in order to compile with the correct name of the bin file.
- a simple .pbs file to make a quick test of the work done. 

The output files have not been included because the results are reported in tabular form in the report.
