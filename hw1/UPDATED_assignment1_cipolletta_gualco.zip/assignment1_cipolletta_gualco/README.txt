The work has been done in pair between me (ANTONIO CIPOLLETTA) and ANDREA GUALCO. 
In the current folder it is possible to find:
- the report.
- all the source files both for the ring and for the hypercube.
- utility script used to automatically 
                                      - generate .pbs files.
                                      - submit multiple jobs.
                                      - generate an output summary file with the overall
                                        performance.

The output files have not been included because the results are reported in tabular form in the report.
